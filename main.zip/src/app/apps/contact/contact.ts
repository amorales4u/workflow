export class Contact {
    img: string;
    name: string;
    post: string;
    address: string;
    contactno: number;
    insta: number;
    linkedin: number;
    facebook: number
}