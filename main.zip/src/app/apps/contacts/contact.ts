export class Contact {
     firstName: string;
     lastName: string;

     mobile: string;
     home: string;
     company: string;
     work: string;
     notes: string;
     imagePath: string;
} 