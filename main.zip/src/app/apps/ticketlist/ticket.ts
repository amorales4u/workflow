export class Ticket {
    Id: number;
    Status: string;
    Label: string;
    ticketTitle: string;
    ticketDescription: string;
    AgentName: string;
    Date: Date
}