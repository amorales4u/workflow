export class ToDo {
    id: number;
    public message: string;
    public completionStatus: boolean;
    public edit: boolean;
    public date: Date;
}