export class User {
    public id: number;
    public Name: string;
    public Position: string;
    public Email: string;
    public Mobile: number;
    public DateOfJoining: Date;
    public Salary: number;
    public Projects: number;
    public imagePath:string;
  }