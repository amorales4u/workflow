import { Component } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup2.component.html'
})
export class Signup2Component {
  constructor() {}
}
