import { Component } from '@angular/core';
@Component({
  selector: 'app-activity-pages',
  templateUrl: './activity-pages.component.html'
})
export class ActivitypagesComponent {
  constructor() {}
}
