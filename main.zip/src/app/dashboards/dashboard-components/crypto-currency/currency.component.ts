import { Component } from '@angular/core';
@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html'
})
export class CurrencyComponent {
  constructor() {}
}
