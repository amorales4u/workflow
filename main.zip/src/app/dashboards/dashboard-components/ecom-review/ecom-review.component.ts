import { Component } from '@angular/core';
@Component({
  selector: 'app-ecom-review',
  templateUrl: './ecom-review.component.html'
})
export class EcomReviewComponent {
  constructor() {}
}
