import { Component } from '@angular/core';
@Component({
  selector: 'app-email-compaign2',
  templateUrl: './email-compaign2.component.html'
})
export class Emailcompaign2Component {
  constructor() {}
}
