import { Component } from '@angular/core';
@Component({
  selector: 'app-profile-activity',
  templateUrl: './profile-activity.component.html'
})
export class ProfileactivityComponent {
  constructor() {}
}
