import { Component } from '@angular/core';
@Component({
  selector: 'app-project2',
  templateUrl: './project2.component.html'
})
export class Project2Component {
  constructor() {}
}
