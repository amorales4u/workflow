export const single = [
  {
    name: 'Germany',
    value: 40
  },
  {
    name: 'USA',
    value: 24
  },
  {
    name: 'France',
    value: 36
  },
  {
    name: 'India',
    value: 36
  },
  {
    name: 'Spain',
    value: 33
  },
  {
    name: 'Italy',
    value: 35
  }
];
