import { Component } from '@angular/core';
@Component({
  selector: 'app-top-referrals',
  templateUrl: './top-referrals.component.html'
})
export class TopreferralsComponent {
  constructor() {}
}
