import { Component } from '@angular/core';
@Component({
  selector: 'app-weather-header',
  templateUrl: './weather-header.component.html'
})
export class WeatherheaderComponent {
  constructor() {}
}
