import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard10.component.html',
  styleUrls: ['./dashboard10.component.css']
})
export class Dashboard10Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
