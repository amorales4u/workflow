import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard8.component.html',
  styleUrls: ['./dashboard8.component.css']
})
export class Dashboard8Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
