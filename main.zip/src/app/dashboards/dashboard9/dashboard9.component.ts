import { Component, AfterViewInit } from '@angular/core';

@Component({
  templateUrl: './dashboard9.component.html',
  styleUrls: ['./dashboard9.component.css']
})
export class Dashboard9Component implements AfterViewInit {
  constructor() {}

  ngAfterViewInit() {}
}
