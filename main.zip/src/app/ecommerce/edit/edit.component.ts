import { Component } from '@angular/core';
@Component({
  templateUrl: 'edit.component.html'
})
export class EditComponent {}
