export class Table {
    Id: number;
    public Name: string;
    public UserName: string;
    public Email: string;
    imagePath:string
  }